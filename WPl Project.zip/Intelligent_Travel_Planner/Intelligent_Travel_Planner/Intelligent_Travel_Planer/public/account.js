const daysofWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function formatTimeComponent(time){
    let formattedTime = time < 10 ? '0' : '';
    return formattedTime + time;
}
function displayDateTime(){
    let currentDate = new Date();
    let today = daysofWeek[currentDate.getDay()];
    let hours = currentDate.getHours();
    let mins = currentDate.getMinutes();
    let secs = currentDate.getSeconds();
    minutes = formatTimeComponent(mins);
    seconds = formatTimeComponent(secs);
    let formattedDateTime = `${today}, ${currentDate.toLocaleDateString()} - ${hours}:${minutes}:${seconds}`;
    document.getElementById('datetime').innerText = formattedDateTime;
}

function changeFontSize() {
    const fontSize = document.getElementById('fontsize').value;
    let mainContent = document.getElementById('mainContent');
    const backGroundCl = document.getElementById('backgr').value;

    mainContent.className = fontSize;
    mainContent.classList.add(backGroundCl);
    localStorage.setItem('backgroundColor',backGroundCl);
    localStorage.setItem('fontSize', fontSize);
}
function changeBackgroundColor() {
    const backGroundCl = document.getElementById('backgr').value;
    let mainContent = document.getElementById('mainContent');
    const fontSize = document.getElementById('fontsize').value;

    mainContent.className = backGroundCl;
    mainContent.classList.add(fontSize);
    localStorage.setItem('backgroundColor',backGroundCl);
    localStorage.setItem('fontSize', fontSize);

    const div = document.getElementById("mainContent");
    const inp = div.getElementsByTagName("input");
    const lab = div.getElementsByTagName("label");
    const leg = div.getElementsByTagName("legend");
    const p = div.getElementsByTagName("p");
    const h3 = div.getElementsByTagName("h3");
    const texttar = div.getElementsByTagName("textarea");

    if(backGroundCl == "black"){
        for(let input of inp){
            input.style.color = "white";
        }
        for(let label of lab){
            label.style.color = "white";
        }
        for(let legend of leg){
            legend.style.color = "white";
        }
        for(let ps of p){
            ps.style.color = "white";
        }
        for(let h3s of h3){
            h3s.style.color = "white";
        }
        for(let tex of texttar){
            tex.style.color = "white";
        }
    }else{
        for(let input of inp){
            input.style.color = "black";
        }
        for(let label of lab){
            label.style.color = "black";
        }
        for(let legend of leg){
            legend.style.color = "black";
        }
        for(let ps of p){
            ps.style.color = "black";
        }
        for(let h3s of h3){
            h3s.style.color = "black";
        }
        for(let tex of texttar){
            tex.style.color = "black";
        }
    }
}
function updateInputchanges(){
    const savedBgColor = localStorage.getItem('backgroundColor');
    const backGroundCl = !!savedBgColor ? savedBgColor : document.getElementById('backgr').value;

    const div = document.getElementById("mainContent");
    const inp = div.getElementsByTagName("input");
    const lab = div.getElementsByTagName("label");
    const leg = div.getElementsByTagName("legend");
    const p = div.getElementsByTagName("p");
    const h3 = div.getElementsByTagName("h3");
    const texttar = div.getElementsByTagName("textarea");

    if(backGroundCl == "black"){
        for(let input of inp){
            input.style.color = "white";
        }
        for(let label of lab){
            label.style.color = "white";
        }
        for(let legend of leg){
            legend.style.color = "white";
        }
        for(let ps of p){
            ps.style.color = "white";
        }
        for(let h3s of h3){
            h3s.style.color = "white";
        }
        for(let tex of texttar){
            tex.style.color = "white";
        }
    }else{
        for(let input of inp){
            input.style.color = "black";
        }
        for(let label of lab){
            label.style.color = "black";
        }
        for(let legend of leg){
            legend.style.color = "black";
        }
        for(let ps of p){
            ps.style.color = "black";
        }
        for(let h3s of h3){
            h3s.style.color = "black";
        }
        for(let tex of texttar){
            tex.style.color = "black";
        }
    }
}
function applychanges(){
    const savedBgColor = localStorage.getItem('backgroundColor');
    const savedFontSize = localStorage.getItem('fontSize');
    let mainContent = document.getElementById('mainContent');
    let fontSize = document.getElementById('fontsize');
    let backGroundCl = document.getElementById('backgr');

    if(savedBgColor && savedFontSize){
        mainContent.className = savedBgColor;
        mainContent.classList.add(savedFontSize);
        fontSize.value = savedFontSize;
        backGroundCl.value = savedBgColor;
    }else if(savedBgColor){
        mainContent.className = savedBgColor;
        backGroundCl.value = savedBgColor;
    }else if(savedFontSize){
        mainContent.className = savedFontSize;
        fontSize.value = savedFontSize;
    }
    updateInputchanges();
}

function activePage(){
    const currentFullPath = window.location.pathname;
    const splitsPath = currentFullPath.split("/");
    const currentPath = "./" + splitsPath[splitsPath.length-1];
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        if (link.getAttribute('href') == currentPath) {
            link.classList.add('active');
        }else{
            link.classList.remove('active');
        }
    });
}
async function fetchUserInfo() {
    const userInfo = document.getElementById('userInfo');
    try {
        const response = await fetch('/user-info');
        if (response.status === 200) {
            const user = await response.json();
            userInfo.innerHTML = `<b>Welcome, ${user.fname} ${user.lname}</b><br>`;
        } else {
            userInfo.innerHTML = 'Please <a href="./login.html">login</a> to submit a comment.';
        }
    } catch (error) {
        userInfo.innerHTML = 'Please <a href="./login.html">login</a> to submit a comment.';;
    }
}
function formatDateToMMDDYYYY(dateString) {
    const date = new Date(dateString);
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
}

async function searchFlightBooking() {
    const flightBookingId = document.getElementById('flightBookingIdInput').value;
    if (!flightBookingId) {
        alert('Please enter a flight booking ID');
        return;
    }

    try {
        const response = await fetch(`/get-flight-booking/${flightBookingId}`);
        if (!response.ok) {
            throw new Error('Failed to fetch flight booking');
        }
        const { flightBooking, passengers } = await response.json();
        displayFlightBooking(flightBooking, passengers);
    } catch (error) {
        console.error('Error fetching flight booking:', error);
        alert('Error fetching flight booking');
    }
}
function displayFlightBooking(flightBooking, passengers) {
    const flightBookingDetails = document.getElementById('flightBookingDetails');
    
    flightBookingDetails.innerHTML = `
        <h3>Flight Booking Details</h3>
        <p><b>Flight Booking ID:</b> ${flightBooking.flight_booking_id}</p>
        <p><b>Flight ID:</b> ${flightBooking.flight_id}</p>
        <p><b>Origin:</b> ${flightBooking.origin}</p>
        <p><b>Destination:</b> ${flightBooking.destination}</p>
        <p><b>Departure Date:</b> ${formatDateToMMDDYYYY(flightBooking.departure_date)}</p>
        <p><b>Arrival Date:</b> ${formatDateToMMDDYYYY(flightBooking.arrival_date)}</p>
        <p><b>Departure Time:</b> ${flightBooking.departure_time}</p>
        <p><b>Arrival Time:</b> ${flightBooking.arrival_time}</p>
        <p><b>Total Price:</b> $${flightBooking.total_price}</p>
        <h4>Passenger Details</h4>
    `;

    passengers.forEach(passenger => {
        const passengerDiv = document.createElement('div');
        passengerDiv.innerHTML = `
            <p><b>Ticket ID:</b> ${passenger.ticket_id}</p>
            <p><b>SSN:</b> ${passenger.ssn}</p>
            <p><b>First Name:</b> ${passenger.first_name}</p>
            <p><b>Last Name:</b> ${passenger.last_name}</p>
            <p><b>Date of Birth:</b> ${formatDateToMMDDYYYY(passenger.date_of_birth)}</p>
            <p><b>Category:</b> ${passenger.category}</p>
            <p><b>Price:</b> $${passenger.price}</p>
            <hr>
        `;
        flightBookingDetails.appendChild(passengerDiv);
    });
}

async function searchHotelBooking() {
    const hotelBookingId = document.getElementById('hotelBookingIdInput').value;
    if (!hotelBookingId) {
        alert('Please enter a hotel booking ID');
        return;
    }

    try {
        const response = await fetch(`/get-hotel-booking/${hotelBookingId}`);
        if (!response.ok) {
            throw new Error('Failed to fetch hotel booking');
        }
        const { hotelBooking, guests } = await response.json();
        displayHotelBooking(hotelBooking, guests);
    } catch (error) {
        console.error('Error fetching hotel booking:', error);
        alert('Error fetching hotel booking');
    }
}
function displayHotelBooking(hotelBooking, guests) {
    const hotelBookingDetails = document.getElementById('hotelBookingDetails');
    hotelBookingDetails.innerHTML = `
        <h3>Hotel Booking Details</h3>
        <p><b>Hotel Booking ID:</b> ${hotelBooking.hotel_booking_id}</p>
        <p><b>Hotel ID:</b> ${hotelBooking.hotel_id}</p>
        <p><b>Hotel Name:</b> ${hotelBooking.hotel_name}</p>
        <p><b>City:</b> ${hotelBooking.city}</p>
        <p><b>Check-in Date:</b> ${formatDateToMMDDYYYY(hotelBooking.check_in_date)}</p>
        <p><b>Check-out Date:</b> ${formatDateToMMDDYYYY(hotelBooking.check_out_date)}</p>
        <p><b>Number of Rooms:</b> ${hotelBooking.number_of_rooms}</p>
        <p><b>Price per Night:</b> $${hotelBooking.price_per_night}</p>
        <p><b>Total Price:</b> $${hotelBooking.total_price}</p>
        <h4>Guest Details</h4>
    `;

    guests.forEach(guest => {
        const guestDiv = document.createElement('div');
        guestDiv.innerHTML = `
            <p><b>SSN:</b> ${guest.ssn}</p>
            <p><b>First Name:</b> ${guest.first_name}</p>
            <p><b>Last Name:</b> ${guest.last_name}</p>
            <p><b>Date of Birth:</b> ${formatDateToMMDDYYYY(guest.date_of_birth)}</p>
            <p><b>Category:</b> ${guest.category}</p>
            <hr>
        `;
        hotelBookingDetails.appendChild(guestDiv);
    });
}
async function fetchSeptemberBookings() {
    try {
        const response = await fetch('/bookings/september-2024');
        if (!response.ok) {
            throw new Error('Failed to fetch bookings for September 2024');
        }
        const { flightBookings, hotelBookings } = await response.json();
        displaySeptemberBookings(flightBookings, hotelBookings);
    } catch (error) {
        console.error('Error fetching September bookings:', error);
        alert("Error fetching September bookings");
    }
}

function displaySeptemberBookings(flightBookings, hotelBookings) {
    const bookingsDiv = document.getElementById('flightBookingDetailsSept');
    bookingsDiv.innerHTML = '<h3>Bookings for September 2024</h3>';

    flightBookings.forEach(booking => {
        console.log("flight each");
        const flightDiv = document.createElement('div');
        flightDiv.innerHTML = `
            <p><b>Flight Booking ID:</b> ${booking.flight_booking_id}</p>
            <p><b>Flight ID:</b> ${booking.flight_id}</p>
            <p><b>Origin:</b> ${booking.origin}</p>
            <p><b>Destination:</b> ${booking.destination}</p>
            <p><b>Departure Date:</b> ${formatDateToMMDDYYYY(booking.departure_date)}</p>
            <p><b>Arrival Date:</b> ${formatDateToMMDDYYYY(booking.arrival_date)}</p>
            <p><b>Total Price:</b> $${booking.total_price}</p>
            <hr>
        `;
        bookingsDiv.appendChild(flightDiv);
    });

    hotelBookings.forEach(booking => {
        console.log("hotel each");
        const hotelDiv = document.createElement('div');
        hotelDiv.innerHTML = `
            <p><b>Hotel Booking ID:</b> ${booking.hotel_booking_id}</p>
            <p><b>Hotel ID:</b> ${booking.hotel_id}</p>
            <p><b>Hotel Name:</b> ${booking.hotel_name}</p>
            <p><b>City:</b> ${booking.city}</p>
            <p><b>Check-in Date:</b> ${formatDateToMMDDYYYY(booking.check_in_date)}</p>
            <p><b>Check-out Date:</b> ${formatDateToMMDDYYYY(booking.check_out_date)}</p>
            <p><b>Total Price:</b> $${booking.total_price}</p>
            <hr>
        `;
        bookingsDiv.appendChild(hotelDiv);
    });
}
async function fetchFlightsBySSN() {
    const ssn = document.getElementById('flightBookingIdInputSSN').value;
    if(!ssn){
        alert("Please enter SSN");
        return;
    }
    try {
        const response = await fetch(`/bookings/flights/${ssn}`);
        if (!response.ok) {
            throw new Error('Failed to fetch booked flights for this SSN');
        }
        const bookedFlights = await response.json();
        displayFlightsBySSN(bookedFlights);
    } catch (error) {
        console.error('Error fetching booked flights by SSN:', error);
        alert("Error fetching booked flights by SSN");
    }
}

function displayFlightsBySSN(bookedFlights) {
    const flightsDiv = document.getElementById('flightBookingDetailsSSN');
    flightsDiv.innerHTML = '<h3>Booked Flights</h3>';

    bookedFlights.forEach(flight => {
        const flightDiv = document.createElement('div');
        flightDiv.innerHTML = `
            <p><b>Flight Booking ID:</b> ${flight.flight_booking_id}</p>
            <p><b>Flight ID:</b> ${flight.flight_id}</p>
            <p><b>Origin:</b> ${flight.origin}</p>
            <p><b>Destination:</b> ${flight.destination}</p>
            <p><b>Departure Date:</b> ${formatDateToMMDDYYYY(flight.departure_date)}</p>
            <p><b>Arrival Date:</b> ${formatDateToMMDDYYYY(flight.arrival_date)}</p>
            <p><b>Passenger Name:</b> ${flight.first_name} ${flight.last_name}</p>
            <p><b>SSN:</b> ${flight.ssn}</p>
            <p><b>Ticket Price:</b> $${flight.price}</p>
            <hr>
        `;
        flightsDiv.appendChild(flightDiv);
    });
}

async function userAdminActions(){
    const isAdmin = await checkIfAdmin();
    console.log(isAdmin);
    console.log("final");
    if (isAdmin) {
        document.getElementById('adminSection').style.display = 'block';
    }else{
        document.getElementById('userSection').style.display = 'block';
    }

    // Add event listeners for user-specific actions
    document.getElementById("searchFlightBooking").addEventListener("click", function(event){
        event.preventDefault();
        searchFlightBooking();
    });
    document.getElementById("searchHotelBooking").addEventListener("click", function(event){
        event.preventDefault();
        searchHotelBooking();
    });
    document.getElementById("searchFlightBookingSept").addEventListener("click", function(event){
        event.preventDefault();
        fetchSeptemberBookings();
    });
    document.getElementById("searchFlightBookingSSN").addEventListener("click", function(event){
        event.preventDefault();
        fetchFlightsBySSN();
    });

    // Add event listeners for admin-specific actions
    document.getElementById("fetchFlightsFromTexasBtn").addEventListener("click", function(event){
        event.preventDefault();
        fetchFlightsFromTexas();
    });
    document.getElementById("fetchHotelsInTexasBtn").addEventListener("click", function(event){
        event.preventDefault();
        fetchHotelsInTexas();
    });
    document.getElementById("fetchMostExpensiveHotelsBtn").addEventListener("click", function(event){
        event.preventDefault();
        fetchMostExpensiveHotels();
    });
    document.getElementById("fetchFlightsWithInfantsBtn").addEventListener("click", function(event){
        event.preventDefault();
        fetchFlightsWithInfants();
    });
    document.getElementById("fetchFlightsWithInfantsAndChildrenBtn").addEventListener("click", function(event){
        event.preventDefault();
        fetchFlightsWithInfantsAndChildren();
    });
    document.getElementById("fetchMostExpensiveFlightsBtn").addEventListener("click", function(event){
        event.preventDefault();
        fetchMostExpensiveFlights();
    });
    document.getElementById("fetchFlightsFromTexasNoInfantBtn").addEventListener("click", function(event){
        event.preventDefault();
        fetchFlightsFromTexasNoInfant();
    });
    document.getElementById("fetchFlightsArrivingInCaliforniaBtn").addEventListener("click", function(event){
        event.preventDefault();
        fetchFlightsArrivingInCalifornia();
    });
}

async function checkIfAdmin() {
    try {
        const response = await fetch('/is-admin');
        if (!response.ok) throw new Error('Failed to check admin status');
        const { isAdmin } = await response.json();
        console.log(isAdmin);
        return isAdmin;
    } catch (error) {
        console.error('Error checking admin status:', error);
        return false;
    }
}

// Admin-specific functions
async function fetchFlightsFromTexas() {
    try {
        const response = await fetch('/admin/bookings/flights/texas');
        if (!response.ok) throw new Error('Failed to fetch flights from Texas');
        const flights = await response.json();
        displayResults('flightsFromTexas', flights, 'Flights from Texas');
    } catch (error) {
        console.error('Error:', error);
        alert("No Flights Found!");
    }
}

async function fetchHotelsInTexas() {
    try {
        const response = await fetch('/admin/bookings/hotels/texas');
        if (!response.ok) throw new Error('Failed to fetch hotels in Texas');
        const hotels = await response.json();
        displayResults('hotelsInTexas', hotels, 'Hotels in Texas');
    } catch (error) {
        console.error('Error:', error);
        alert("No Hotels Found!");
    }
}

async function fetchMostExpensiveHotels() {
    try {
        const response = await fetch('/admin/bookings/hotels/most-expensive');
        if (!response.ok) throw new Error('Failed to fetch most expensive hotels');
        const hotels = await response.json();
        displayResults('mostExpensiveHotels', hotels, 'Most Expensive Hotels');
    } catch (error) {
        console.error('Error:', error);
        alert("Error");
    }
}

async function fetchFlightsWithInfants() {
    try {
        const response = await fetch('/admin/bookings/flights/infant');
        if (!response.ok) throw new Error('Failed to fetch flights with infants');
        const flights = await response.json();
        displayResults('flightsWithInfants', flights, 'Flights with Infants');
    } catch (error) {
        console.error('Error:', error);
        alert("No Flights found with Infants!");
    }
}

async function fetchFlightsWithInfantsAndChildren() {
    try {
        const response = await fetch('/admin/bookings/flights/infant-children');
        if (!response.ok) throw new Error('Failed to fetch flights with infants and children');
        const flights = await response.json();
        displayResults('flightsWithInfantsAndChildren', flights, 'Flights with Infants and Children');
    } catch (error) {
        console.error('Error:', error);
        alert("No flights found with Infant and atleast 5 children!");
    }
}

async function fetchMostExpensiveFlights() {
    try {
        const response = await fetch('/admin/bookings/flights/most-expensive');
        if (!response.ok) throw new Error('Failed to fetch most expensive flights');
        const flights = await response.json();
        displayResults('mostExpensiveFlights', flights, 'Most Expensive Flights');
    } catch (error) {
        console.error('Error:', error);
        alert("Error");
    }
}

async function fetchFlightsFromTexasNoInfant() {
    try {
        const response = await fetch('/admin/bookings/flights/texas-no-infant');
        if (!response.ok) throw new Error('Failed to fetch flights from Texas with no infant');
        const flights = await response.json();
        displayResults('flightsFromTexasNoInfant', flights, 'Flights from Texas with No Infant');
    } catch (error) {
        console.error('Error:', error);
        alert("No Flights without infants found!");
    }
}

async function fetchFlightsArrivingInCalifornia() {
    try {
        const response = await fetch('/admin/bookings/flights/california-arrivals');
        if (!response.ok) throw new Error('Failed to fetch flights arriving in California');
        const { count } = await response.json();
        document.getElementById('flightsArrivingInCalifornia').innerText = `Count: ${count}`;
    } catch (error) {
        console.error('Error:', error);
        alert("No Flights arriving in California found!");
    }
}

function displayResults(elementId, data, title) {
    const container = document.getElementById(elementId);
    container.innerHTML = `<h3>${title}</h3>`;
    data.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.innerHTML = Object.entries(item).map(([key, value]) => `<p><b>${key}:</b> ${value}</p>`).join('');
        itemDiv.innerHTML += '<hr>';
        container.appendChild(itemDiv);
    });
}
document.addEventListener('DOMContentLoaded', () => {
    displayDateTime();
    setInterval(displayDateTime, 1000);
    applychanges();
    activePage();
    fetchUserInfo();
    document.getElementById("fontsize").addEventListener("change", function(event){
        event.preventDefault();
        changeFontSize();
    });
    document.getElementById("backgr").addEventListener("change", function(event){
        event.preventDefault();
        changeBackgroundColor();
    });
    
    userAdminActions();
});
