const daysofWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function formatTimeComponent(time){
    let formattedTime = time < 10 ? '0' : '';
    return formattedTime + time;
}
function displayDateTime(){
    let currentDate = new Date();
    let today = daysofWeek[currentDate.getDay()];
    let hours = currentDate.getHours();
    let mins = currentDate.getMinutes();
    let secs = currentDate.getSeconds();
    minutes = formatTimeComponent(mins);
    seconds = formatTimeComponent(secs);
    let formattedDateTime = `${today}, ${currentDate.toLocaleDateString()} - ${hours}:${minutes}:${seconds}`;
    document.getElementById('datetime').innerText = formattedDateTime;
}
function changeFontSize() {
    const fontSize = document.getElementById('fontsize').value;
    let mainContent = document.getElementById('mainContent');
    const backGroundCl = document.getElementById('backgr').value;

    mainContent.className = fontSize;
    mainContent.classList.add(backGroundCl);
    localStorage.setItem('backgroundColor',backGroundCl);
    localStorage.setItem('fontSize', fontSize);
}

function changeBackgroundColor() {
    const backGroundCl = document.getElementById('backgr').value;
    let mainContent = document.getElementById('mainContent');
    const fontSize = document.getElementById('fontsize').value;

    mainContent.className = backGroundCl;
    mainContent.classList.add(fontSize);
    localStorage.setItem('backgroundColor',backGroundCl);
    localStorage.setItem('fontSize', fontSize);
    
    const div = document.getElementById("mainContent");
    const inp = div.getElementsByTagName("input");
    const lab = div.getElementsByTagName("label");
    const leg = div.getElementsByTagName("legend");
    const p = div.getElementsByTagName("p");
    const h3 = div.getElementsByTagName("h3");
    const h2 = div.getElementsByTagName("h2");
    const texttar = div.getElementsByTagName("textarea");

    if(backGroundCl == "black"){
        for(let input of inp){
            input.style.color = "white";
        }
        for(let label of lab){
            label.style.color = "white";
        }
        for(let legend of leg){
            legend.style.color = "white";
        }
        for(let ps of p){
            ps.style.color = "white";
        }
        for(let h3s of h3){
            h3s.style.color = "white";
        }
        for(let h2s of h2){
            h2s.style.color = "white";
        }
        for(let tex of texttar){
            tex.style.color = "white";
        }
    }else{
        for(let input of inp){
            input.style.color = "black";
        }
        for(let label of lab){
            label.style.color = "black";
        }
        for(let legend of leg){
            legend.style.color = "black";
        }
        for(let ps of p){
            ps.style.color = "black";
        }
        for(let h3s of h3){
            h3s.style.color = "black";
        }
        for(let h2s of h2){
            h2s.style.color = "black";
        }
        for(let tex of texttar){
            tex.style.color = "black";
        }
    }
}
function applychanges(){
    const savedBgColor = localStorage.getItem('backgroundColor');
    const savedFontSize = localStorage.getItem('fontSize');
    let mainContent = document.getElementById('mainContent');
    let fontSize = document.getElementById('fontsize');
    let backGroundCl = document.getElementById('backgr');

    if(savedBgColor && savedFontSize){
        mainContent.className = savedBgColor;
        mainContent.classList.add(savedFontSize);
        fontSize.value = savedFontSize;
        backGroundCl.value = savedBgColor;
    }else if(savedBgColor){
        mainContent.className = savedBgColor;
        backGroundCl.value = savedBgColor;
    }else if(savedFontSize){
        mainContent.className = savedFontSize;
        fontSize.value = savedFontSize;
    }
}
function activePage(){
    const currentFullPath = window.location.pathname;
    const splitsPath = currentFullPath.split("/");
    const currentPath = "./" + splitsPath[splitsPath.length-1];
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        if (link.getAttribute('href') == currentPath) {
            link.classList.add('active');
        }else{
            link.classList.remove('active');
        }
    });
}
async function fetchBookingDetails(flightBookingId) {
    try {
        const response = await fetch(`/booking-details/${flightBookingId}`);
        const data = await response.json();
        if (response.ok) {
            displayTicketDetails(data.tickets);
        } else {
            throw new Error(data.error || 'Failed to fetch booking details');
        }
    } catch (error) {
        console.error('Error:', error);
    }
}
async function displayFullInfo(totalPass,departFlightID,returnFlightID, adults, children, infant, adultPr, childPr, infantPr, totalprice,
    returnadultPr, returnchildPr, returninfantPr, returntotalprice){
    const finalDiv = document.getElementsByClassName("displayFullFlightInfo")[0];
    const h3div = document.createElement("h3");
    h3div.innerHTML = "Booking successful. Final Details are: ";
    finalDiv.appendChild(h3div);

    const flightInfoDiv = document.createElement("div");
    flightInfoDiv.classList.add("finalFlightBooking");

    const flightDetailsVal = localStorage.getItem('flightVal');
    let tickets = [];
    let insertBookings = [];
    let bookingId;
    let returnbookingId;
    if(flightDetailsVal){
        const flightDetails = JSON.parse(flightDetailsVal);
        const randomNum = Math.floor(Math.random() * 90)+10;
        const randomNum2 = Math.floor(Math.random() * 90)+10;
        bookingId = flightDetails.fId.substr(0,2) + randomNum + flightDetails.fId.substr(2,2) + randomNum2 + flightDetails.fId.substr(4);
        const detailsDiv = document.createElement("div");
        detailsDiv.innerHTML = `
        <h2>Departing Flight Details: </h2>
        <p><b>Booking ID: </b>${bookingId}</p>
        <p><b>Flight ID: </b>${flightDetails.fId}</p>
        <p><b>Origin: </b>${flightDetails.origin}</p>
        <p><b>Destination: </b>${flightDetails.dest}</p>
        <p><b>Departure Date: </b>${flightDetails.departureDate}</p>
        <p><b>Arrival Date: </b>${flightDetails.arrivalDate}</p>
        <p><b>Departure Time: </b>${flightDetails.departureTime}</p>
        <p><b>Arrival Time: </b>${flightDetails.arrivalTime}</p>
        <p><b>Total Price: </b>${totalprice}</p>
        `;
        flightInfoDiv.appendChild(detailsDiv);
        const bookingDetails = {
            bookingId: bookingId,
            flightId: flightDetails.fId,
            price: totalprice,
            totalPass: totalPass
        };
        insertBookings.push(bookingDetails);
        // try {
        //     const response = await fetch('/insert-flight-bookings', {
        //         method: 'POST',
        //         headers: {
        //             'Content-Type': 'application/json',
        //         },
        //         body: JSON.stringify({ bookingDetails }),
        //     });
        //     const result = await response.json();
        //     alert(result.message);
        // } catch (error) {
        //     console.error('Error:', error);
        //     alert(result.message);
        // }
    }

    const returnflightDetailsVal = localStorage.getItem('returnFlightVal');
    if(returnflightDetailsVal){
        const returnflightDetails = JSON.parse(returnflightDetailsVal);
        const returnrandomNum = Math.floor(Math.random() * 90)+10;
        const returnrandomNum2 = Math.floor(Math.random() * 90)+10;
        returnbookingId = returnflightDetails.fId.substr(0,2) + returnrandomNum + returnflightDetails.fId.substr(2,2) + returnrandomNum2 + returnflightDetails.fId.substr(4);
        const returndetailsDiv = document.createElement("div");
        returndetailsDiv.innerHTML = `
        <h2>Returning Flight Details: </h2>
        <p><b>Booking ID: </b>${returnbookingId}</p>
        <p><b>Flight ID: </b>${returnflightDetails.fId}</p>
        <p><b>Origin: </b>${returnflightDetails.origin}</p>
        <p><b>Destination: </b>${returnflightDetails.dest}</p>
        <p><b>Departure Date: </b>${returnflightDetails.departureDate}</p>
        <p><b>Arrival Date: </b>${returnflightDetails.arrivalDate}</p>
        <p><b>Departure Time: </b>${returnflightDetails.departureTime}</p>
        <p><b>Arrival Time: </b>${returnflightDetails.arrivalTime}</p>
        <p><b>Total Price: </b>${returntotalprice}</p>
        `;
        flightInfoDiv.appendChild(returndetailsDiv);
        const returnBookingDetails = {
            bookingId: returnbookingId,
            flightId: returnflightDetails.fId,
            price: returntotalprice,
            totalPass: totalPass
        };
        insertBookings.push(returnBookingDetails);
        // try {
        //     const response = await fetch('/insert-flight-bookings', {
        //         method: 'POST',
        //         headers: {
        //             'Content-Type': 'application/json',
        //         },
        //         body: JSON.stringify({ returnBookingDetails }),
        //     });
        //     const result = await response.json();
        //     alert(result.message);
        // } catch (error) {
        //     console.error('Error:', error);
        //     alert(result.message);
        // }
    }
    try {
        const response = await fetch('/insert-flight-bookings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ insertBookings }),
        });
        const result = await response.json();
        alert(result.message);
    } catch (error) {
        console.error('Error:', error);
        alert(result.message);
    }
    finalDiv.appendChild(flightInfoDiv);

    const flightUserInfoDiv = document.createElement("div");
    flightUserInfoDiv.classList.add("finalUserFlightBooking");
    const returnflightUserInfoDiv = document.createElement("div");
    returnflightUserInfoDiv.classList.add("finalUserFlightBooking");
    let passengers = [];
    let numAd = adults;
    let numCh= children;
    let numIn = infant;
    for(let i=0; i<totalPass; i++){
        const fname = document.getElementById(`fname-${i}`).value;
        const lname = document.getElementById(`lname-${i}`).value;
        const dob = document.getElementById(`dob-${i}`).value;
        const ssn = document.getElementById(`ssn-${i}`).value;
        
        let passPrice;
        let category;
        let returnPassPrice;
        if(numAd != 0){
            category = 'Adult';
            passPrice = adultPr;
            if(returnflightDetailsVal){
                returnPassPrice = returnadultPr;
            }
            numAd = numAd-1;
        }
        else if(numCh != 0){
            category = 'Child';
            passPrice = childPr;
            if(returnflightDetailsVal){
                returnPassPrice = returnchildPr;
            }
            numCh = numCh-1;
        }
        else if(numIn != 0){
            category = 'Infant';
            passPrice = infantPr;
            if(returnflightDetailsVal){
                returnPassPrice = returninfantPr;
            }
            numIn = numIn-1;
        }
        passengers.push({
            fname: fname,
            lname: lname,
            dob: dob,
            ssn: ssn,
            category: category
        });
        tickets.push({
            flight_booking_id: bookingId,
            ssn: ssn,
            price: passPrice
        });
        if(returnflightDetailsVal){
            tickets.push({
                flight_booking_id: returnbookingId,
                ssn: ssn,
                price: returnPassPrice
            });
        }
    }
    
    try {
        const response = await fetch('/insert-passengers', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ passengers }),
        });
        const result = await response.json();
        alert(result.message);
    } catch (error) {
        console.error('Error:', error);
        alert(result.message);
    }

    try {
        const response = await fetch('/insert-tickets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ tickets }),
        });
        const result = await response.json();
        alert(result.message);
    } catch (error) {
        console.error('Error:', error);
        alert(result.message);
    }

    try {
        const response = await fetch(`/booking-details/${bookingId}`);
        const data = await response.json();
        if (response.ok) {
            const dataTickets = data.tickets;
            dataTickets.forEach((tick, index) =>{
                let eachDiv = document.createElement("div");
                eachDiv.innerHTML = `<p><b>Passenger ${index+1}: </b></p>`+`<p><b>Ticket ID: </b> ${tick.ticket_id}</p>`+`<p><b>Booking ID: </b> ${tick.flight_booking_id}</p>`+`<p><b>SSN: </b> ${tick.ssn}</p>`+`<p><b>Name: </b> ${tick.first_name} ${tick.last_name}</p>`+
                `<p><b>Date of Birth: </b> ${new Date(tick.date_of_birth).toLocaleDateString()}</p>`+
                `<p><b>Price: </b> ${tick.price}</p>`;
                flightUserInfoDiv.appendChild(eachDiv);
            });
            finalDiv.appendChild(flightUserInfoDiv);
        } else {
            throw new Error(data.error || 'Failed to fetch booking details');
        }
    } catch (error) {
        console.error('Error:', error);
    }
    if(returnflightDetailsVal){
        try {
            const response = await fetch(`/booking-details/${returnbookingId}`);
            const data = await response.json();
            if (response.ok) {
                const dataTickets = data.tickets;
                dataTickets.forEach((tick, index) =>{
                    let eachDiv = document.createElement("div");
                    eachDiv.innerHTML = `<p><b>Passenger ${index+1}: </b></p>`+`<p><b>Ticket ID: </b> ${tick.ticket_id}</p>`+`<p><b>Booking ID: </b> ${tick.flight_booking_id}</p>`+`<p><b>SSN: </b> ${tick.ssn}</p>`+`<p><b>Name: </b> ${tick.first_name} ${tick.last_name}</p>`+
                    `<p><b>Date of Birth: </b> ${new Date(tick.date_of_birth).toLocaleDateString()}</p>`+
                    `<p><b>Price: </b> ${tick.price}</p>`;
                    returnflightUserInfoDiv.appendChild(eachDiv);
                });
                finalDiv.appendChild(returnflightUserInfoDiv);
            } else {
                throw new Error(data.error || 'Failed to fetch booking details');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }


    // const submitbtn = document.createElement("input");
    // submitbtn.type = "submit";
    // submitbtn.id = "fileUpdateSubmit";
    // finalDiv.appendChild(submitbtn);
    // document.getElementById('fileUpdateSubmit').addEventListener('click', function(event){
    //     event.preventDefault();
    //     updateFileDoc(totalPass, departFlightID, returnFlightID);
    // });
}
function displayFlightDetails(){

    const mainDiv = document.getElementsByClassName("flightBookingDetails")[0];
    const flightDetailsVal = localStorage.getItem('flightVal');
    let totalPass = 0;
    let departFlightID = "";
    let returnFlightID = "";
    let adults = 0;
    let children = 0;
    let infant = 0;
    let adultPr = 0;
    let childPr = 0;
    let infantPr = 0;
    let totalprice = 0;
    let returnadultPr = 0;
    let returnchildPr = 0;
    let returninfantPr = 0;
    let returntotalprice = 0;

    if(flightDetailsVal){
        const flightDetails = JSON.parse(flightDetailsVal);
        const price = parseInt(flightDetails.price);
        const adultNum = parseInt(flightDetails.adultPass);
        const childNum = parseInt(flightDetails.childPass);
        const infantNum = parseInt(flightDetails.infantPass);
        const adultPrice = price*adultNum;
        const childPrice = price*childNum*0.7;
        const infantPrice = price*infantNum*0.1;
        totalprice = adultPrice+childPrice+infantPrice;
        adults = adultNum;
        children = childNum;
        infant = infantNum;
        adultPr = adultPrice;
        childPr = childPrice;
        infantPr = infantPrice;
        const detailsDiv = document.createElement("div");
        detailsDiv.innerHTML = `
        <h2>Flight Booking Details:</h2>
        <h3>Flight Details:</h3>
        <p><b>Flight ID: </b>${flightDetails.fId}</p>
        <p><b>Origin: </b>${flightDetails.origin}</p>
        <p><b>Destination: </b>${flightDetails.dest}</p>
        <p><b>Departure Date: </b>${flightDetails.departureDate}</p>
        <p><b>Arrival Date: </b>${flightDetails.arrivalDate}</p>
        <p><b>Departure Time: </b>${flightDetails.departureTime}</p>
        <p><b>Arrival Time: </b>${flightDetails.arrivalTime}</p>
        <p><b>Number of Adults: </b>${adultNum}</p>
        <p><b>Number of Children: </b>${childNum}</p>
        <p><b>Number of Infants: </b>${infantNum}</p>
        <p><b>Total Flight Price: </b>${totalprice}</p>
        `;
        mainDiv.appendChild(detailsDiv);
        totalPass = adultNum+childNum+infantNum;
        departFlightID = flightDetails.fId;
    }
    
    const returnFlightDetailsVal = localStorage.getItem('returnFlightVal');
    if(returnFlightDetailsVal){
        const returnFlightDetails = JSON.parse(returnFlightDetailsVal);
        const returnprice = parseInt(returnFlightDetails.price);
        const returnadultNum = parseInt(returnFlightDetails.adultPass);
        const returnchildNum = parseInt(returnFlightDetails.childPass);
        const returninfantNum = parseInt(returnFlightDetails.infantPass);
        const returnadultPrice = returnprice*returnadultNum;
        const returnchildPrice = returnprice*returnchildNum*0.7;
        const returninfantPrice = returnprice*returninfantNum*0.1;
        returntotalprice = returnadultPrice+returnchildPrice+returninfantPrice;
        const returnDetailsDiv = document.createElement("div");
        returnDetailsDiv.classList.add("returnFlight");
        returnadultPr = returnadultPrice;
        returnchildPr = returnchildPrice;
        returninfantPr = returninfantPrice;
        returnDetailsDiv.innerHTML = `
        <h3>Return Flight Details:</h3>
        <p><b>Flight ID: </b>${returnFlightDetails.fId}</p>
        <p><b>Origin: </b>${returnFlightDetails.origin}</p>
        <p><b>Destination: </b>${returnFlightDetails.dest}</p>
        <p><b>Departure Date: </b>${returnFlightDetails.departureDate}</p>
        <p><b>Arrival Date: </b>${returnFlightDetails.arrivalDate}</p>
        <p><b>Departure Time: </b>${returnFlightDetails.departureTime}</p>
        <p><b>Arrival Time: </b>${returnFlightDetails.arrivalTime}</p>
        <p><b>Number of Adults: </b>${returnadultNum}</p>
        <p><b>Number of Children: </b>${returnchildNum}</p>
        <p><b>Number of Infants: </b>${returninfantNum}</p>
        <p><b>Total Flight Price: </b>${returntotalprice}</p>
        `;
        mainDiv.appendChild(returnDetailsDiv);
        returnFlightID = returnFlightDetails.fId;
    }
    userForms(totalPass,departFlightID,returnFlightID, adults, children, infant, adultPr, childPr, infantPr, totalprice,
        returnadultPr, returnchildPr, returninfantPr, returntotalprice);
}
function userForms(totalPass,departFlightID,returnFlightID, adults, children, infant, adultPr, childPr, infantPr, totalprice,
    returnadultPr, returnchildPr, returninfantPr, returntotalprice){
    const userDiv = document.getElementsByClassName("userFlightDetails")[0];
    const userForm = document.createElement("form");
    userForm.id = "userForms";
    for(let i=0; i<totalPass; i++){
        let eachDiv = document.createElement("div");
        eachDiv.classList.add("flightUserInfo");
        let flabel = document.createElement("label");
        flabel.htmlFor = `fname-${i}`;
        flabel.innerHTML = "First Name";
        
        let finput = document.createElement("input");
        finput.type = "text";
        finput.id = `fname-${i}`;
        finput.placeholder = "Enter your first name";
        finput.required = true;

        eachDiv.appendChild(flabel);
        eachDiv.appendChild(finput);

        let llabel = document.createElement("label");
        llabel.htmlFor = `lname-${i}`;
        llabel.innerHTML = "Last Name";
        
        let linput = document.createElement("input");
        linput.type = "text";
        linput.id = `lname-${i}`;
        linput.placeholder = "Enter your last name";
        linput.required = true;

        eachDiv.appendChild(llabel);
        eachDiv.appendChild(linput);

        let doblabel = document.createElement("label");
        doblabel.htmlFor = `dob-${i}`;
        doblabel.innerHTML = "Date of Birth";
        
        let dobinput = document.createElement("input");
        dobinput.type = "date";
        dobinput.id = `dob-${i}`;
        dobinput.required = true;

        eachDiv.appendChild(doblabel);
        eachDiv.appendChild(dobinput);

        let ssnlabel = document.createElement("label");
        ssnlabel.htmlFor = `ssn-${i}`;
        ssnlabel.innerHTML = "SSN";
        
        let ssninput = document.createElement("input");
        ssninput.type = "text";
        ssninput.id = `ssn-${i}`;
        ssninput.placeholder = "Enter your SSN";
        ssninput.required = true;

        eachDiv.appendChild(ssnlabel);
        eachDiv.appendChild(ssninput);

        userForm.appendChild(eachDiv);
    }
    const submitbtn = document.createElement("input");
    submitbtn.type = "submit";
    submitbtn.id = "finalsubmit";
    userForm.appendChild(submitbtn);
    userDiv.appendChild(userForm);

    document.getElementById('userForms').addEventListener('submit', function(event){
        event.preventDefault();
        displayFullInfo(totalPass,departFlightID,returnFlightID, adults, children, infant, adultPr, childPr, infantPr, totalprice,
            returnadultPr, returnchildPr, returninfantPr, returntotalprice);
    })
}
async function sendHotelBookingToServer(hotelBooking, hotelGuests) {
    console.log('Hotel Booking:', hotelBooking);
    console.log('Hotel Guests:', hotelGuests);
    try {
        const response = await fetch('/book-hotel', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ hotelBooking, hotelGuests }),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const result = await response.json();
        console.log(result.message);
        alert(result.message);
        // You can add further actions here, like showing a success message to the user
    } catch (error) {
        console.error('Error:', error);
        alert("There was an error inserting to hotel bookings and guests table");
        // Handle the error, maybe show an error message to the user
    }
}
function displayFullInfoHotel(totalHotelPass, adults, child, infants, hotelId, checkIn, checkOut, roomsNum, price, totalPrice, hotelName, hotelCity){
    let numAd = adults;
    let numCh= child;
    let numIn = infants;
    const uniqueBookingId = String(hotelId) + String(Math.floor(Math.random() * 90)+10) + String(hotelId);
    let hotelGuests = [];
    for(let i=0; i<totalHotelPass; i++){
        const fname = document.getElementById(`fnamehotel-${i}`).value;
        const lname = document.getElementById(`lnamehotel-${i}`).value;
        const dob = document.getElementById(`dobhotel-${i}`).value;
        const ssn = document.getElementById(`ssnhotel-${i}`).value;
        
        let passPrice;
        let category;
        let returnPassPrice;
        if(numAd != 0){
            category = 'Adult';
            numAd = numAd-1;
        }
        else if(numCh != 0){
            category = 'Child';
            numCh = numCh-1;
        }
        else if(numIn != 0){
            category = 'Infant';
            numIn = numIn-1;
        }
        hotelGuests.push({
            ssn: ssn,
            hotel_booking_id: uniqueBookingId,
            fname: fname,
            lname: lname,
            dob: dob,
            category: category
        })
    }
    const hotelBookings = {
        hotel_booking_id:uniqueBookingId,
        hotel_id: hotelId,
        checkIn: checkIn,
        checkOut: checkOut,
        roomsNum: roomsNum,
        price: price,
        totalPrice: totalPrice
    };

    // Send data to server
    sendHotelBookingToServer(hotelBookings, hotelGuests);

    const finalDivHotel = document.getElementsByClassName("displayFullHotelInfo")[0];
    const h3div = document.createElement("h3");
    h3div.innerHTML = "Booking successful. Final Details are: ";
    finalDivHotel.appendChild(h3div);

    const hotelInfoDiv = document.createElement("div");
    hotelInfoDiv.classList.add("finalHotelBooking");

    const detailsDiv = document.createElement("div");
    detailsDiv.innerHTML = `
    <h2>Hotel and User Details: </h2>
    <p><b>Hotel Booking ID: </b>${uniqueBookingId}</p>
    <p><b>Hotel ID: </b>${hotelId}</p>
    <p><b>Hotel Name: </b>${hotelName}</p>
    <p><b>Hotel City: </b>${hotelCity}</p>
    <p><b>Price Per Night: </b>${price}</p>
    <p><b>Check In Date: </b>${checkIn}</p>
    <p><b>Check Out Date: </b>${checkOut}</p>
    <p><b>Num of Rooms: </b>${roomsNum}</p>
    <p><b>Total Price: </b>${totalPrice}</p>

    `;
    hotelInfoDiv.appendChild(detailsDiv);
    const hotelUserInfoDiv = document.createElement("div");
    hotelUserInfoDiv.classList.add("finalUserHotelBooking");
    hotelGuests.forEach((guest, index) => {
        let eachDiv = document.createElement("div");
        eachDiv.innerHTML = `<p><b>Guest ${index+1}: </b></p>`+`<p><b>SSN: </b> ${guest.ssn}</p>`+`<p><b>First Name: </b> ${guest.fname}</p>`+`<p><b>Last Name: </b> ${guest.lname}</p>`+`<p><b>Category: </b> ${guest.category}</p>`;
        hotelUserInfoDiv.appendChild(eachDiv);
    });
    hotelInfoDiv.appendChild(hotelUserInfoDiv);
    finalDivHotel.appendChild(hotelInfoDiv);

}
function hotelUserForms(totalHotelPass, adults, child, infants, hotelId, checkIn, checkOut, roomsNum, price, totalPrice, hotelName, hotelCity){
    const userDiv = document.getElementsByClassName("userHotelDetails")[0];
    const userForm = document.createElement("form");
    userForm.id = "userFormsHotel";
    for(let i=0; i<totalHotelPass; i++){
        let eachDiv = document.createElement("div");
        eachDiv.classList.add("hotelUserInfo");
        let flabel = document.createElement("label");
        flabel.htmlFor = `fnamehotel-${i}`;
        flabel.innerHTML = "First Name";
        
        let finput = document.createElement("input");
        finput.type = "text";
        finput.id = `fnamehotel-${i}`;
        finput.placeholder = "Enter your first name";
        finput.required = true;

        eachDiv.appendChild(flabel);
        eachDiv.appendChild(finput);

        let llabel = document.createElement("label");
        llabel.htmlFor = `lnamehotel-${i}`;
        llabel.innerHTML = "Last Name";
        
        let linput = document.createElement("input");
        linput.type = "text";
        linput.id = `lnamehotel-${i}`;
        linput.placeholder = "Enter your last name";
        linput.required = true;

        eachDiv.appendChild(llabel);
        eachDiv.appendChild(linput);

        let doblabel = document.createElement("label");
        doblabel.htmlFor = `dobhotel-${i}`;
        doblabel.innerHTML = "Date of Birth";
        
        let dobinput = document.createElement("input");
        dobinput.type = "date";
        dobinput.id = `dobhotel-${i}`;
        dobinput.required = true;

        eachDiv.appendChild(doblabel);
        eachDiv.appendChild(dobinput);

        let ssnlabel = document.createElement("label");
        ssnlabel.htmlFor = `ssnhotel-${i}`;
        ssnlabel.innerHTML = "SSN";
        
        let ssninput = document.createElement("input");
        ssninput.type = "text";
        ssninput.id = `ssnhotel-${i}`;
        ssninput.placeholder = "Enter your SSN";
        ssninput.required = true;

        eachDiv.appendChild(ssnlabel);
        eachDiv.appendChild(ssninput);

        userForm.appendChild(eachDiv);
    }
    const submitbtn = document.createElement("input");
    submitbtn.type = "submit";
    submitbtn.id = "finalsubmit";
    userForm.appendChild(submitbtn);
    userDiv.appendChild(userForm);

    document.getElementById('userFormsHotel').addEventListener('submit', function(event){
        event.preventDefault();
        displayFullInfoHotel(totalHotelPass, adults, child, infants, hotelId, checkIn, checkOut, roomsNum, price, totalPrice, hotelName, hotelCity);
    })
}
function displayHotelDetails(){
    const hotelListVal = localStorage.getItem('hotelList');
    if(hotelListVal){
        const hotelList = JSON.parse(hotelListVal);
        const hotelDiv = document.getElementsByClassName("hotelBookings")[0];
        hotelDiv.innerHTML = `
        <h2><u>Hotel Booking Details:</u></h2>
        <p><b>Hotel ID: </b>${hotelList.hotelId}</p>
        <p><b>Hotel Name: </b>${hotelList.hotelName}</p>
        <p><b>City: </b>${hotelList.hotelCity}</p>
        <p><b>Number of Adults: </b>${hotelList.adultNum}</p>
        <p><b>Number of Children: </b>${hotelList.childNum}</p>
        <p><b>Number of Infants: </b>${hotelList.infantNum}</p>
        <p><b>Number of Rooms: </b>${hotelList.roomsNum}</p>
        <p><b>Price per night for each room: </b>${hotelList.price}</p>
        <p><b>Check In Date: </b>${hotelList.checkIn}</p>
        <p><b>Check Out Date: </b>${hotelList.checkOut}</p>
        <p><b>Total Price: </b>${hotelList.totalPrice}</p>
        `;
        const totalHotelPass = hotelList.adultNum + hotelList.childNum + hotelList.infantNum;
        hotelUserForms(totalHotelPass, hotelList.adultNum, hotelList.childNum, hotelList.infantNum, hotelList.hotelId, hotelList.checkIn, hotelList.checkOut, hotelList.roomsNum, hotelList.price, hotelList.totalPrice, hotelList.hotelName, hotelList.hotelCity);
    }
}
async function fetchUserInfo() {
    const userInfo = document.getElementById('userInfo');
    try {
        const response = await fetch('/user-info');
        if (response.status === 200) {
            const user = await response.json();
            userInfo.innerHTML = `<b>Welcome, ${user.fname} ${user.lname}</b><br>`;
        } else {
            userInfo.innerHTML = 'Please <a href="./login.html">login</a> to submit a comment.';
        }
    } catch (error) {
        userInfo.innerHTML = 'Please <a href="./login.html">login</a> to submit a comment.';;
    }
}
document.addEventListener('DOMContentLoaded', () => {
    displayDateTime();
    setInterval(displayDateTime, 1000);
    applychanges();
    activePage();
    fetchUserInfo();
    displayFlightDetails();
    displayHotelDetails();
    document.getElementById("fontsize").addEventListener("change", function(event){
        event.preventDefault();
        changeFontSize();
    });
    document.getElementById("backgr").addEventListener("change", function(event){
        event.preventDefault();
        changeBackgroundColor();
    });
});
function updateFileDoc(totalPass, departFlightID, returnFlightID){
    let xhr = new XMLHttpRequest();
    xhr.open("GET", "flightsList2.xml", false);
    xhr.send();
    const xmlString = xhr.responseText;

    const parser = new DOMParser();
    const flightDoc = parser.parseFromString(xmlString, 'application/xml');
    const flights = flightDoc.getElementsByTagName('Flight');

    for (let i = 0; i < flights.length; i++) {
        const flight = flights[i];
        const id = flight.getElementsByTagName('FlightID')[0].textContent;
        if (id === departFlightID) {
            const availableSeats = flight.getElementsByTagName('AvailableSeats')[0].textContent;
            flight.getElementsByTagName('AvailableSeats')[0].textContent = availableSeats - totalPass;
            break;
        }
        if(returnFlightID && id === returnFlightID){
            const returnavailableSeats = flight.getElementsByTagName('AvailableSeats')[0].textContent;
            flight.getElementsByTagName('AvailableSeats')[0].textContent = returnavailableSeats - totalPass;
            break;
        }
    }

    const updatedXML = serializeXML(flightDoc);
    downloadXML('flightsList2.xml', updatedXML);
}