const daysofWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function formatTimeComponent(time){
    let formattedTime = time < 10 ? '0' : '';
    return formattedTime + time;
}
function displayDateTime(){
    let currentDate = new Date();
    let today = daysofWeek[currentDate.getDay()];
    let hours = currentDate.getHours();
    let mins = currentDate.getMinutes();
    let secs = currentDate.getSeconds();
    minutes = formatTimeComponent(mins);
    seconds = formatTimeComponent(secs);
    let formattedDateTime = `${today}, ${currentDate.toLocaleDateString()} - ${hours}:${minutes}:${seconds}`;
    document.getElementById('datetime').innerText = formattedDateTime;
}

function changeFontSize() {
    const fontSize = document.getElementById('fontsize').value;
    let mainContent = document.getElementById('mainContent');
    const backGroundCl = document.getElementById('backgr').value;

    mainContent.className = fontSize;
    mainContent.classList.add(backGroundCl);
    localStorage.setItem('backgroundColor',backGroundCl);
    localStorage.setItem('fontSize', fontSize);
}

function changeBackgroundColor() {
    const backGroundCl = document.getElementById('backgr').value;
    let mainContent = document.getElementById('mainContent');
    const fontSize = document.getElementById('fontsize').value;

    mainContent.className = backGroundCl;
    mainContent.classList.add(fontSize);
    localStorage.setItem('backgroundColor',backGroundCl);
    localStorage.setItem('fontSize', fontSize);
    
}

function applychanges(){
    const savedBgColor = localStorage.getItem('backgroundColor');
    const savedFontSize = localStorage.getItem('fontSize');
    let mainContent = document.getElementById('mainContent');
    let fontSize = document.getElementById('fontsize');
    let backGroundCl = document.getElementById('backgr');

    if(savedBgColor && savedFontSize){
        mainContent.className = savedBgColor;
        mainContent.classList.add(savedFontSize);
        fontSize.value = savedFontSize;
        backGroundCl.value = savedBgColor;
    }else if(savedBgColor){
        mainContent.className = savedBgColor;
        backGroundCl.value = savedBgColor;
    }else if(savedFontSize){
        mainContent.className = savedFontSize;
        fontSize.value = savedFontSize;
    }
}
function activePage(){
    const currentFullPath = window.location.pathname;
    const splitsPath = currentFullPath.split("/");
    const currentPath = "./" + splitsPath[splitsPath.length-1];
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        if (link.getAttribute('href') == currentPath) {
            link.classList.add('active');
        }else{
            link.classList.remove('active');
        }
    });
}
// function validateForm(){
//     let fname = document.getElementById("fname").value;
//     let lname = document.getElementById("lname").value;
//     let phone = document.getElementById("phone").value.trim();
//     let email = document.getElementById("email").value;
//     let dob = document.getElementById("dob").value;
//     let pwd = document.getElementById("pwd").value;
//     let pwdconfirm = document.getElementById("pwdconfirm").value;


//     document.getElementById("ferror").innerHTML = "";
//     document.getElementById("lerror").innerHTML = "";
//     document.getElementById("pherror").innerHTML = "";
//     document.getElementById("emerror").innerHTML = "";
//     document.getElementById("doberror").innerHTML = "";
//     document.getElementById("pwderror").innerHTML = "";
//     document.getElementById("pwdconfirmerror").innerHTML = "";

//     const phoneregex = /^\d{3}-\d{3}-\d{4}$/
//     const emailregex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     const dobregex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/;
//     let validForm = true;

//     if(!phoneregex.test(phone)){
//         validForm = false;
//         document.getElementById("pherror").innerHTML = "Phone number should of the format ddd-ddd-dddd";
//     }
//     if(!emailregex.test(email) || !email.endsWith(".com")){
//         validForm = false;
//         document.getElementById("emerror").innerHTML = "Email must contain @ and end with .com";
//     }
//     if (pwd.length < 8) {
//         validForm = false;
//         document.getElementById("pwderror").innerHTML = "Password length should be atleast 8.";
//     }
//     if (pwd !== pwdconfirm) {
//         validForm = false;
//         document.getElementById("pwdconfirmerror").innerHTML = "Passwords do not match";
//     }
//     if (!dobregex.test(dob)) {
//         validForm = false;
//         document.getElementById("doberror").innerHTML = "Date of birth format is MM/DD/YYYY.";
//     }
// }
function registrationFormValidation(){
    const registrationForm = document.getElementById('formsregister');
    const errorMessages = document.getElementById('errorMessages');

    registrationForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        errorMessages.innerHTML = '';

        const formData = new FormData(registrationForm);
        const data = Object.fromEntries(formData.entries());
        try {
            const response = await fetch('/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            if (response.status === 200) {
                alert(result.message);
                registrationForm.reset();
            } else {
                errorMessages.innerHTML = result.errors.join('<br>');
            }
        } catch (error) {
            errorMessages.innerHTML = 'An error occurred. Please try again later.';
        }
    });
}
document.addEventListener('DOMContentLoaded', () => {
    displayDateTime();
    setInterval(displayDateTime, 1000);
    applychanges();
    activePage();
    registrationFormValidation();
    document.getElementById("fontsize").addEventListener("change", function(event){
        event.preventDefault();
        changeFontSize();
    });
    document.getElementById("backgr").addEventListener("change", function(event){
        event.preventDefault();
        changeBackgroundColor();
    });
});