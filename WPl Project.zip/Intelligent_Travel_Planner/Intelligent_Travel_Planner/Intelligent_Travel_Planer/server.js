const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database');
const helmet = require('helmet');
const session = require('express-session');
const fs = require('fs').promises;
const xml2js = require('xml2js');




const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
// app.use(express.static('public'));
app.use(helmet());

// Set Content Security Policy
app.use(
    helmet.contentSecurityPolicy({
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "https:"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      },
    })
  );

// Set up session middleware
app.use(session({
secret: 'secret_key', // Replace with a strong secret key
resave: false,
saveUninitialized: true,
cookie: { secure: false } // Set secure: true if using HTTPS
}));

// Serve static files
app.use(express.static('public'));

// Default route to serve index.html
const path = require('path');
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
const texasCities = [
    'Dallas',
    'Houston',
    'Austin',
    'San Antonio',
    'El Paso',
    'Fort Worth',
    'Lubbock',
    'Corpus Christi',
    'Midland',
    'Amarillo',
    'Brownsville',
    'Mcallen',
    'Harlingen',
    'Killeen',
    'Waco',
    'Tyler'
];
const caliCities = [
    'College Station',
    'Laredo',
    'Beaumont',
    'Abilene',
    'Los Angeles',
    'San Francisco',
    'San Diego',
    'San Jose',
    'Sacramento',
    'Oakland',
    'Long Beach',
    'Fresno',
    'Santa Barbara',
    'Burbank',
    'Palm Springs',
    'Ontario',
    'John Wayne',
    'Sedding',
    'Monterey',
    'Bakersfield',
    'Stockton',
    'Santa Rosa',
    'Eureka',
    'San Luis Obispo'
];
// Route to handle form submission
app.post('/register', async (req, res) => {
    const { phone, pwd, pwdconfirm, fname, lname, dob, email, gen } = req.body;
    const phoneregex = /^\d{3}-\d{3}-\d{4}$/
    const emailregex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    // const dobregex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/;

    let errors = [];
    if (!phoneregex.test(phone)) {
        errors.push('Phone number must be formatted as ddd-ddd-dddd.');
    }
    if (pwd.length < 8) {
        errors.push('Password must be at least 8 characters.');
    }
    if (pwd !== pwdconfirm) {
        errors.push('Passwords do not match.');
    }
    // if (!dobregex.test(dob)) {
    //     errors.push('Date of birth format must be MM/DD/YYYY.');
    // }
    if (!emailregex.test(email) || !email.endsWith('.com')) {
        errors.push('Email must contain @ and end with .com.');
    }

    if (errors.length > 0) {
        return res.status(400).json({ errors });
    }
    
    try {
        // Check if phone number is unique
        const [existingUser] = await db.query('SELECT phoneNumber FROM users WHERE phoneNumber = ?', [phone]);
        if (existingUser.length > 0) {
            return res.status(400).json({ errors: ['Phone number already exists.'] });
        }

        // Insert user into database
        await db.query(
            'INSERT INTO users (phoneNumber, password, firstName, lastName, dob, gender, email) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [phone, pwd, fname, lname, dob, gen, email]
        );

        res.status(200).json({ message: 'User registered successfully.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ errors: ['Failed to register user.'] });
    }

});

// Login endpoint
app.post('/login', async (req, res) => {
    const { phone, pwd } = req.body;
    if (!phone || !pwd) {
        return res.status(400).json({ errors: ['Phone number and password are required.'] });
    }

    try{
        const [users] = await db.query('SELECT * FROM users WHERE phoneNumber = ?', [phone]);
        if (users.length === 0) {
            return res.status(400).json({ errors: ['Invalid phone number or password.'] });
        }
        const user = users[0];
        const isPasswordValid = pwd === user.password ? true : false;
        if (!isPasswordValid) {
            return res.status(400).json({ errors: ['Invalid phone number or password.'] });
        }
        // Save user info in session
        req.session.user = {
            phone: user.phoneNumber,
            fname: user.firstName,
            lname: user.lastName
        };
        res.status(200).json({ message: 'Login successful.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ errors: ['An error occurred during login.'] });
    }
});
// Endpoint to get user info
app.get('/user-info', (req, res) => {
    if (req.session.user) {
        res.json(req.session.user);
    } else {
        res.status(401).json({ errors: ['User not logged in.'] });
    }
});
// Check if admin or not
app.get('/is-admin', (req, res) => {
    const adminPhoneNumber = '222-222-2222';
    if (req.session.user.phone === adminPhoneNumber) {
        res.json({ isAdmin: true });
    } else {
        res.json({ isAdmin: false });
    }
});

// Serve contact page
app.get('/contact', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'contact.html'));
});

// Submit comment endpoint
app.post('/submit-comment', async (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ errors: ['Please login to submit a comment.'] });
    }

    const { comment } = req.body;
    if (!comment || comment.length < 10) {
        return res.status(400).json({ errors: ['Comment must be at least 10 characters long.'] });
    }

    try {
        const [user] = await db.query('SELECT * FROM users WHERE phoneNumber = ?', [req.session.user.phone]);
        
        if (user.length === 0) {
            return res.status(404).json({ errors: ['User not found.'] });
        }

        const xmlFilePath = path.join(__dirname, 'contactOut.xml');
        let xmlData;
        // Try to read existing XML file
        try {
            const xmlContent = await fs.readFile(xmlFilePath, 'utf-8');
            xmlData = await xml2js.parseStringPromise(xmlContent);
        } catch (error) {
            // If file doesn't exist or is empty, create new structure
            xmlData = { comments: { user: [] } };
        }
        const contactId = Date.now(); // Generate a unique contact ID

        // Format the date to MM-DD-YYYY
        const dobDate = new Date(user[0].dob);
        const formattedDob = `${(dobDate.getMonth() + 1).toString().padStart(2, '0')}-${dobDate.getDate().toString().padStart(2, '0')}-${dobDate.getFullYear()}`;
        const newComment = {
            'contact-id': [contactId.toString()],
            'phone-number': [user[0].phoneNumber],
            'first-name': [user[0].firstName],
            'last-name': [user[0].lastName],
            'date-of-birth': formattedDob,
            'email': [user[0].email],
            'gender': [user[0].gender],
            'comment': [comment]
        };

        // Check if user already exists
        const existingUserIndex = xmlData.comments.user.findIndex(u => u['phone-number'][0] === user[0].phoneNumber);

        if (existingUserIndex !== -1) {
            // Update existing user's comment
            xmlData.comments.user[existingUserIndex] = newComment;
        } else {
            // Add new user
            xmlData.comments.user.push(newComment);
        }
        const builder = new xml2js.Builder();
        const xml = builder.buildObject(xmlData);

        await fs.writeFile(`contactOut.xml`, xml);

        res.status(200).json({ message: 'Comment submitted successfully.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ errors: ['Failed to submit comment.'] });
    }
});


app.post('/insert-passengers', async (req, res) => {
    const { passengers } = req.body;
    let connection;
    try {
        connection = await db.getConnection()

        const query = `
            INSERT INTO passengers (ssn, first_name, last_name, date_of_birth, category)
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            ssn = VALUES(ssn),
            first_name = VALUES(first_name),
            last_name = VALUES(last_name),
            date_of_birth = VALUES(date_of_birth),
            category = VALUES(category)
        `;

        for (const passenger of passengers) {
            await connection.execute(query, [
                passenger.ssn,
                passenger.fname,
                passenger.lname,
                passenger.dob,
                passenger.category
            ]);
        }

        res.json({ message: 'Passengers inserted successfully' });
    } catch (error) {
        console.error('Error inserting passengers:', error);
        res.status(500).json({ message: 'Error inserting passengers' });
    } finally {
        if (connection) connection.release();
    }
});

app.post('/insert-flight-bookings', async (req, res) => {
    const { insertBookings } = req.body;
    let connection;
    try {
        connection = await db.getConnection()

        const query = `
            INSERT INTO flight_bookings (flight_booking_id, flight_id, total_price)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE
            flight_booking_id = VALUES(flight_booking_id),
            flight_id = VALUES(flight_id),
            total_price = VALUES(total_price)
        `;

        for (const bookingDetail of insertBookings) {
            await connection.execute(query, [
                bookingDetail.bookingId,
                bookingDetail.flightId,
                bookingDetail.price,
            ]);
            // Update available seats
            await connection.execute(
            'UPDATE flights SET available_seats = available_seats - ? WHERE flight_id = ?',
            [bookingDetail.totalPass, bookingDetail.flightId]
            );
            
        }


        res.json({ message: 'Flight details are inserted successfully' });
    } catch (error) {
        console.error('Error inserting flight details:', error);
        res.status(500).json({ message: 'Error inserting flight details' });
    } finally {
        if (connection) connection.release();
    }
});

app.post('/insert-tickets', async (req, res) => {
    const { tickets } = req.body;
    let connection;
    try {
        connection = await db.getConnection()

        const query = `
            INSERT INTO tickets (flight_booking_id, ssn, price)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE
            price = VALUES(price)
        `;

        for (const ticket of tickets) {
            await connection.execute(query, [
                ticket.flight_booking_id,
                ticket.ssn,
                ticket.price
            ]);
        }

        res.json({ message: 'Tickets inserted successfully' });
    } catch (error) {
        console.error('Error inserting tickets:', error);
        res.status(500).json({ message: 'Error inserting tickets' });
    } finally {
        if (connection) connection.release();
    }
});

app.get('/booking-details/:flightBookingId', async (req, res) => {
    const { flightBookingId } = req.params;
    let connection;
    try {
        connection = await db.getConnection()
  
      // Fetch ticket details
      const [tickets] = await connection.execute(`
        SELECT t.ticket_id, t.flight_booking_id, t.ssn, p.first_name, p.last_name, p.date_of_birth, t.price
        FROM tickets t
        JOIN passengers p ON t.ssn = p.ssn
        WHERE t.flight_booking_id = ?
      `, [flightBookingId]);
  
      res.json({ tickets });
    } catch (error) {
      console.error('Error fetching booking details:', error);
      res.status(500).json({ error: 'An error occurred while fetching booking details' });
    } finally {
      if (connection) connection.release();
    }
  });
 
  app.post('/book-hotel', async (req, res) => {
    const { hotelBooking, hotelGuests } = req.body;
    let connection;

    try {
        connection = await db.getConnection()
        await connection.beginTransaction();

        // Insert hotel booking
        const queryBook = `
        INSERT INTO hotel_bookings 
        (hotel_booking_id, hotel_id, check_in_date, check_out_date, number_of_rooms, price_per_night, total_price)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        hotel_booking_id = VALUES(hotel_booking_id),
        hotel_id = VALUES(hotel_id),
        check_in_date = VALUES(check_in_date),
        check_out_date = VALUES(check_out_date),
        number_of_rooms = VALUES(number_of_rooms),
        price_per_night = VALUES(price_per_night),
        total_price = VALUES(total_price)
        `;
        
        await connection.execute(queryBook,[
            hotelBooking.hotel_booking_id,
            hotelBooking.hotel_id,
            hotelBooking.checkIn,
            hotelBooking.checkOut,
            hotelBooking.roomsNum,
            hotelBooking.price,
            hotelBooking.totalPrice
        ]);
        
        // Insert guests
        const queryGuest = `
        INSERT INTO guests 
        (ssn, hotel_booking_id, first_name, last_name, date_of_birth, category)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        ssn = VALUES(ssn),
        hotel_booking_id = VALUES(hotel_booking_id),
        first_name = VALUES(first_name),
        last_name = VALUES(last_name),
        date_of_birth = VALUES(date_of_birth),
        category = VALUES(category)
        `;

        for (const guest of hotelGuests) {
            await connection.execute(queryGuest, [
                guest.ssn,
                guest.hotel_booking_id,
                guest.fname,
                guest.lname,
                guest.dob,
                guest.category
            ]);
        }

        await connection.commit();
        res.json({ message: 'Hotel booking and guests added successfully' });
    } catch (error) {
        console.error('Error booking hotel:', error);
        res.status(500).json({ error: 'An error occurred while booking the hotel' });
    } finally {
        if (connection) connection.release();
    }
});

app.get('/get-flight-booking/:id', async (req, res) => {
    const { id } = req.params;
    let connection;
    try {
        connection = await db.getConnection();

        // Fetch flight booking details
        const [flightBookings] = await connection.execute(`
            SELECT fb.flight_booking_id, fb.flight_id, f.origin, f.destination, 
                   f.departure_date, f.arrival_date, f.departure_time, f.arrival_time, fb.total_price
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            WHERE fb.flight_booking_id = ?
        `, [id]);

        if (flightBookings.length === 0) {
            return res.status(404).json({ error: 'Flight booking not found' });
        }

        // Fetch passenger details
        const [passengers] = await connection.execute(`
            SELECT t.ticket_id, t.flight_booking_id, t.ssn, p.first_name, p.last_name, 
                   p.date_of_birth, p.category, t.price
            FROM tickets t
            JOIN passengers p ON t.ssn = p.ssn
            WHERE t.flight_booking_id = ?
        `, [id]);

        res.json({ flightBooking: flightBookings[0], passengers });
    } catch (error) {
        console.error('Error fetching flight booking:', error);
        res.status(500).json({ error: 'An error occurred while fetching flight booking' });
    } finally {
        if (connection) connection.release();
    }
});

app.get('/get-hotel-booking/:id', async (req, res) => {
    const { id } = req.params;
    let connection;
    try {
        connection = await db.getConnection();

        // Fetch hotel booking details
        const [hotelBookings] = await connection.execute(`
            SELECT hb.hotel_booking_id, hb.hotel_id, h.hotel_name, h.city, 
                   hb.number_of_rooms, hb.check_in_date, hb.check_out_date, 
                   hb.price_per_night, hb.total_price
            FROM hotel_bookings hb
            JOIN hotels h ON hb.hotel_id = h.hotel_id
            WHERE hb.hotel_booking_id = ?
        `, [id]);

        if (hotelBookings.length === 0) {
            return res.status(404).json({ error: 'Hotel booking not found' });
        }

        // Fetch guest details
        const [guests] = await connection.execute(`
            SELECT g.ssn, g.first_name, g.last_name, g.date_of_birth, g.category
            FROM guests g
            WHERE g.hotel_booking_id = ?
        `, [id]);

        res.json({ hotelBooking: hotelBookings[0], guests });
    } catch (error) {
        console.error('Error fetching hotel booking:', error);
        res.status(500).json({ error: 'An error occurred while fetching hotel booking' });
    } finally {
        if (connection) connection.release();
    }
});

app.get('/bookings/september-2024', async (req, res) => {
    const { fname, lname } = req.session.user;
    if (!fname || !lname) {
        return res.status(401).json({ error: 'User not authenticated' });
    }
    let connection;
    try {
        connection = await db.getConnection();

        // Fetch flight bookings for September 2024
        const [flightBookings] = await connection.execute(`
            SELECT fb.flight_booking_id, fb.flight_id, f.origin, f.destination, 
            f.departure_date, f.arrival_date, f.departure_time, f.arrival_time, fb.total_price
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            JOIN tickets t ON fb.flight_booking_id = t.flight_booking_id
            JOIN passengers p ON t.ssn = p.ssn
            WHERE LOWER(p.first_name) = LOWER(?) AND LOWER(p.last_name) = LOWER(?)
            AND MONTH(f.departure_date) = 9 AND YEAR(f.departure_date) = 2024
        `, [fname, lname]);
        console.log(flightBookings);
        // Fetch hotel bookings for September 2024
        const [hotelBookings] = await connection.execute(`
            SELECT hb.hotel_booking_id, hb.hotel_id, h.hotel_name, h.city, 
            hb.number_of_rooms, hb.check_in_date, hb.check_out_date, 
            hb.price_per_night, hb.total_price
            FROM hotel_bookings hb
            JOIN hotels h ON hb.hotel_id = h.hotel_id
            JOIN guests g ON hb.hotel_booking_id = g.hotel_booking_id
            WHERE g.first_name = ? AND g.last_name = ? 
            AND ((MONTH(hb.check_in_date) = 9 AND YEAR(hb.check_in_date) = 2024)
            OR (MONTH(hb.check_out_date) = 9 AND YEAR(hb.check_out_date) = 2024))
            `, [fname, lname]);
        res.json({ flightBookings, hotelBookings });
    } catch (error) {
        console.error('Error fetching bookings:', error);
        res.status(500).json({ error: 'An error occurred while fetching bookings' });
    } finally {
        if (connection) connection.release();
    }
});

app.get('/bookings/flights/:ssn', async (req, res) => {
    const { ssn } = req.params;
    let connection;
    try {
        connection = await db.getConnection();
        // Fetch flight bookings for the specific SSN
        const [bookedFlights] = await connection.execute(`
            SELECT fb.flight_booking_id, fb.flight_id, f.origin, f.destination, 
                   f.departure_date, f.arrival_date, f.departure_time, f.arrival_time, fb.total_price,
                   t.ticket_id, t.ssn, p.first_name, p.last_name, p.date_of_birth, t.price
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            JOIN tickets t ON fb.flight_booking_id = t.flight_booking_id
            JOIN passengers p ON t.ssn = p.ssn
            WHERE t.ssn = ?
        `, [ssn]);
        if (bookedFlights.length === 0) {
            return res.status(404).json({ error: 'No bookings found for this SSN' });
        }

        res.json(bookedFlights);
    } catch (error) {
        console.error('Error fetching booked flights:', error);
        res.status(500).json({ error: 'An error occurred while fetching booked flights' });
    } finally {
        if (connection) connection.release();
    }
});

// Retrieved all booked flights will departure from a city in Texas from sep 2024 to oct 2024
app.get('/admin/bookings/flights/texas', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [flights] = await connection.execute(`
            SELECT fb.flight_booking_id, f.flight_id, f.origin, f.destination, 
                   f.departure_date, f.arrival_date, f.departure_time, f.arrival_time, fb.total_price
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            WHERE f.origin IN (${texasCities.map(city => `'${city}'`).join(', ')}) AND 
                  f.departure_date BETWEEN '2024-09-01' AND '2024-10-31'
        `);
        if (flights.length === 0) {
            return res.status(404).json({ error: 'No bookings found for a city in Texas between September and October.' });
        }
        res.json(flights);
    } catch (error) {
        console.error('Error fetching flights:', error);
        res.status(500).json({ error: 'An error occurred while fetching flights' });
    } finally {
        if (connection) connection.release();
    }
});

// Retrieve All Booked Hotels in a City in Texas (Sep 2024 to Oct 2024)
app.get('/admin/bookings/hotels/texas', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [hotels] = await connection.execute(`
            SELECT hb.hotel_booking_id, hb.hotel_id, h.hotel_name, h.city, 
                   hb.number_of_rooms, hb.check_in_date, hb.check_out_date, 
                   hb.price_per_night, hb.total_price
            FROM hotel_bookings hb
            JOIN hotels h ON hb.hotel_id = h.hotel_id
            WHERE h.city IN (${texasCities.map(city => `'${city}'`).join(', ')}) AND 
                  (hb.check_in_date BETWEEN '2024-09-01' AND '2024-10-31' OR 
                   hb.check_out_date BETWEEN '2024-09-01' AND '2024-10-31')
        `);
        if (hotels.length === 0) {
            return res.status(404).json({ error: 'No bookings found for a city in Texas between September and October.' });
        }
        res.json(hotels);
    } catch (error) {
        console.error('Error fetching hotels:', error);
        res.status(500).json({ error: 'An error occurred while fetching hotels' });
    } finally {
        if (connection) connection.release();
    }
});

// Most Expensive hotel
app.get('/admin/bookings/hotels/most-expensive', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [hotels] = await connection.execute(`
            SELECT hb.hotel_booking_id, hb.hotel_id, h.hotel_name, h.city, 
                   hb.number_of_rooms, hb.check_in_date, hb.check_out_date, 
                   hb.price_per_night, hb.total_price
            FROM hotel_bookings hb
            JOIN hotels h ON hb.hotel_id = h.hotel_id
            ORDER BY hb.total_price DESC
            LIMIT 1
        `);
        
        res.json(hotels);
    } catch (error) {
        console.error('Error fetching most expensive hotels:', error);
        res.status(500).json({ error: 'An error occurred while fetching hotels' });
    } finally {
        if (connection) connection.release();
    }
});

// Flights with Infants
app.get('/admin/bookings/flights/infant', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [flights] = await connection.execute(`
            SELECT DISTINCT fb.flight_booking_id, f.flight_id, f.origin, f.destination, 
                   f.departure_date, f.arrival_date, f.departure_time, f.arrival_time, fb.total_price
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            JOIN tickets t ON fb.flight_booking_id = t.flight_booking_id
            JOIN passengers p ON t.ssn = p.ssn
            WHERE p.category = 'Infant'
        `);
        if (flights.length === 0) {
            return res.status(404).json({ error: 'Flight booking with infants not found' });
        }
        res.json(flights);
    } catch (error) {
        console.error('Error fetching flights with infants:', error);
        res.status(500).json({ error: 'An error occurred while fetching flights' });
    } finally {
        if (connection) connection.release();
    }
});

// Retrieve All Booked Flights with an Infant Passenger and at Least 5 Children
app.get('/admin/bookings/flights/infant-children', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [flights] = await connection.execute(`
            SELECT fb.flight_booking_id, f.flight_id, f.origin, f.destination, 
                   f.departure_date, f.arrival_date, f.departure_time, f.arrival_time, fb.total_price
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            JOIN tickets t ON fb.flight_booking_id = t.flight_booking_id
            JOIN passengers p ON t.ssn = p.ssn
            WHERE p.category = 'Infant'
            GROUP BY fb.flight_booking_id
            HAVING SUM(CASE WHEN p.category = 'Child' THEN 1 ELSE 0 END) >= 5
        `);
        if (flights.length === 0) {
            return res.status(404).json({ error: 'Flight booking with infants and atleast 5 children not found' });
        }
        res.json(flights);
    } catch (error) {
        console.error('Error fetching flights with infants and children:', error);
        res.status(500).json({ error: 'An error occurred while fetching flights' });
    } finally {
        if (connection) connection.release();
    }
});

// Retrieve All Information for Most Expensive Booked Flights
app.get('/admin/bookings/flights/most-expensive', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [flights] = await connection.execute(`
            SELECT fb.flight_booking_id, f.flight_id, f.origin, f.destination, 
                   f.departure_date, f.arrival_date, f.departure_time, f.arrival_time, fb.total_price
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            ORDER BY fb.total_price DESC
            LIMIT 1
        `);

        res.json(flights);
    } catch (error) {
        console.error('Error fetching most expensive flights:', error);
        res.status(500).json({ error: 'An error occurred while fetching flights' });
    } finally {
        if (connection) connection.release();
    }
});

// Retrieve All Booked Flights Departing from a City in Texas with No Infant Passenger
app.get('/admin/bookings/flights/texas-no-infant', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [flights] = await connection.execute(`
            SELECT fb.flight_booking_id, f.flight_id, f.origin, f.destination, 
                   f.departure_date, f.arrival_date, f.departure_time, f.arrival_time, fb.total_price
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            WHERE f.origin IN (${texasCities.map(city => `'${city}'`).join(', ')}) AND 
                  fb.flight_booking_id NOT IN (
                      SELECT DISTINCT fb.flight_booking_id
                      FROM flight_bookings fb
                      JOIN tickets t ON fb.flight_booking_id = t.flight_booking_id
                      JOIN passengers p ON t.ssn = p.ssn
                      WHERE p.category = 'Infant'
                  )
        `);
        if (flights.length === 0) {
            return res.status(404).json({ error: 'Flight booking with no infants from a city in Texas not found' });
        }
        res.json(flights);
    } catch (error) {
        console.error('Error fetching flights from Texas with no infants:', error);
        res.status(500).json({ error: 'An error occurred while fetching flights' });
    } finally {
        if (connection) connection.release();
    }
});

// Retrieve the Number of Booked Flights Arriving in a City in California (Sep 2024 to Oct 2024)
app.get('/admin/bookings/flights/california-arrivals', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [result] = await connection.execute(`
            SELECT COUNT(*) AS count
            FROM flight_bookings fb
            JOIN flights f ON fb.flight_id = f.flight_id
            WHERE f.destination IN (${caliCities.map(city => `'${city}'`).join(', ')}) AND 
                  f.arrival_date BETWEEN '2024-09-01' AND '2024-10-31'
        `);

        res.json({ count: result[0].count });
    } catch (error) {
        console.error('Error fetching flights arriving in California:', error);
        res.status(500).json({ error: 'An error occurred while fetching flights' });
    } finally {
        if (connection) connection.release();
    }
});


// Start the server
app.listen(3000, () => {
    console.log('Server started on port 3000');
});
