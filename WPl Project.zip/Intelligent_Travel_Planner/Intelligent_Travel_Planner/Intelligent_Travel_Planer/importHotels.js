const mysql = require('mysql2/promise');
const fs = require('fs').promises;

const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: 'Anusai@123',
    database: 'flight_database'
};

async function importHotels() {
    let connection;

    try {
        // Read the JSON file
        const data = await fs.readFile('Hotels.json', 'utf8');
        const hotels = JSON.parse(data);

        // Connect to the database
        connection = await mysql.createConnection(dbConfig);

        // Prepare the SQL query
        const query = `
            INSERT INTO hotels (hotel_id, hotel_name, city, price_per_night)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            hotel_id = VALUES(hotel_id),
            hotel_name = VALUES(hotel_name),
            city = VALUES(city),
            price_per_night = VALUES(price_per_night)
        `;

        // Insert each hotel
        for (const hotel of hotels) {
            await connection.execute(query, [
                hotel.hotel_id,
                hotel.hotel_name,
                hotel.city,
                hotel.price
            ]);
        }

        console.log('Hotels imported successfully');
    } catch (error) {
        console.error('Error importing hotels:', error);
    } finally {
        if (connection) {
            await connection.end();
        }
    }
}

importHotels();