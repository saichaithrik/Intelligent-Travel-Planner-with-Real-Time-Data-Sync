const fs = require('fs');
const xml2js = require('xml2js');
const mysql = require('mysql2/promise');

const xmlFilePath = 'flightsList2.xml'; // Path to your XML file

async function parseXML(filePath) {
    const parser = new xml2js.Parser();
    const xmlData = fs.readFileSync(filePath, 'utf-8');
    return parser.parseStringPromise(xmlData);
}

async function insertFlights(flights) {
    const connection = await mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'Anusai@123',
        database: 'flight_database'
    });

    const insertQuery = `
        INSERT INTO flights (
            flight_id, origin, destination, departure_date, arrival_date, departure_time, arrival_time, available_seats, price
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            flight_id = VALUES(flight_id),
            origin = VALUES(origin),
            destination = VALUES(destination),
            departure_date = VALUES(departure_date),
            arrival_date = VALUES(arrival_date),
            departure_time = VALUES(departure_time),
            arrival_time = VALUES(arrival_time),
            available_seats = VALUES(available_seats),
            price = VALUES(price)
    `;

    for (const flight of flights.Flights.Flight) {
        const flightData = [
            flight.FlightID[0],
            flight.Origin[0],
            flight.Destination[0],
            flight.DepartureDate[0],
            flight.ArrivalDate[0],
            flight.DepartureTime[0],
            flight.ArrivalTime[0],
            parseInt(flight.AvailableSeats[0], 10),
            parseFloat(flight.Price[0])
        ];

        await connection.execute(insertQuery, flightData);
    }

    await connection.end();
}

async function main() {
    try {
        const flights = await parseXML(xmlFilePath);
        await insertFlights(flights);
        console.log('Flights imported successfully.');
    } catch (error) {
        console.error('Error importing flights:', error);
    }
}

main();